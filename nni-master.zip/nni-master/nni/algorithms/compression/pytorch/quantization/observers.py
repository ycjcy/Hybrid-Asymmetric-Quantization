from torch.quantization import default_weight_observer, default_histogram_observer

__all__ = ["default_weight_observer", "default_histogram_observer"]
