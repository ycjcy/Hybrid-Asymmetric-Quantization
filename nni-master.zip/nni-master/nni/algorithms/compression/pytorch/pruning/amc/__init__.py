# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

from .amc_pruner import AMCPruner
