 **NNI 中的自动特征工程** ===

  此[示例](https://github.com/SpongebBob/tabular_automl_NNI)在 NNI 中实现了自动特征工程。

  代码来自于贡献者。 谢谢可爱的贡献者！

 欢迎越来越多的人加入我们！
