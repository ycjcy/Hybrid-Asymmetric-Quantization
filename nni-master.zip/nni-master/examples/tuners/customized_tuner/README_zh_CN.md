# 如何将自定义的 Tuner 安装为内置 Tuner

参考[文档](https://github.com/microsoft/nni/blob/master/docs/zh_CN/Tuner/InstallCustomizedTuner.md)， 安装自定义 Tuner。