---
name: Enhancement Request
about: Suggest an enhancement to the nni project

---
<!-- Please only use this template for submitting enhancement requests -->


**What would you like to be added**:

**Why is this needed**:

**Without this feature, how does current nni work**：

**Components that may involve changes**:

**Brief description of your proposal if any**:
